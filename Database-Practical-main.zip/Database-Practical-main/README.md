# Database-Practical
This is the code of Database Practical 
